


const Comments = require('../models/commentsModel');

// Get all Comments
exports.readAllComment = (req, res) => {
    Comments.find({}, (error, Comments) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : Comments.length,
                Comments
            });
        }
    });
}

// Create a Comment
exports.createAComment = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newComment = new Comment(req.body);

    newComment.save((error, Comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(Comment);
        }
    });
}


// Get a Comment
exports.readAComment = (req, res) => {
    Comment.findById(req.params.    , (error, Comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(Comment);
        }
    });
}

// Update a Comment
exports.updateAComment = (req, res) => {
    Comment.findByIdAndUpdate(req.params.Comment_id, req.body, {new: true}, (error, Comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(Comment);
        }
    });
}

// Delete a Comment
exports.deleteAComment = (req, res) => {
    Comment.findByIdAndDelete(req.params.Comment_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "Article supprimé"});
        }
    });
}
