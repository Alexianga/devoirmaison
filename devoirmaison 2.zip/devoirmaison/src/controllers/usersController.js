


const Users = require('../models/UsersModel');

// Get all Users
exports.readAlluser = (req, res) => {
    Users.find({}, (error, users) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : users.length,
                users
            });
        }
    });
}

// Create a User
exports.createAuser = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newUser = new User(req.body);

    newUser.save((error, User) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(User);
        }
    });
}


// Get a User
exports.readAuser = (req, res) => {
    User.findById(req.params.User_id, (error, User) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(User);
        }
    });
}

// Update a User
exports.updateAuser = (req, res) => {
    User.findByIdAndUpdate(req.params.User_id, req.body, {new: true}, (error, User) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(User);
        }
    });
}

// Delete a User
exports.deleteAuser = (req, res) => {
    User.findByIdAndDelete(req.params.User_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "Article supprimé"});
        }
    });
}




















