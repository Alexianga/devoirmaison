


const commentsController = require('../controllers/commentsController');

module.exports = (server) => {
    server.route("/comments")
    .get(commentsController.readAllComment) // Get all Comments
    .post(commentsController.createAComment); // Create a Comment
    
    server.route("/comments/:Comment_id") // req.params.Comment_id
    .get(commentsController.readAComment) // Get one Comments
    .put(commentsController.updateAComment) // Update one Comment
    .delete(commentsController.deleteAComment); // Delete one Comment
}