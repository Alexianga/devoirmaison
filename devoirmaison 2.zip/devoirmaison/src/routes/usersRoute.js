

const usersController = require('../controllers/usersController');

module.exports = (server) => {
    server.route("/users")
    .get(usersController.readAlluser) // Get all users
    .post(usersController.createAuser); // Create a user
    
    server.route("/users/:user_id") // req.params.user_id
    .get(usersController.readAuser) // Get one users
    .put(usersController.updateAuser) // Update one user
    .delete(usersController.deleteAuser); // Delete one user
}