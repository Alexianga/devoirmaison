const mongoose = require('mongoose');

const Schema = mongoose.Schema;

let CommentSchema = new Schema({
    userID: {
        type: String,
        required: true,
    },
    content: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Comment', CommentSchema);